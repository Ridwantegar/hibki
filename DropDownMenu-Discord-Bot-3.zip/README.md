Don't Share Code To Anyone 
Don't Make Video Without Credits
Some files u won't see here as I won't give it